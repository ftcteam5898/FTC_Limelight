# FTC Sample Detection > 2024-12-25 6:58pm
https://universe.roboflow.com/limelight-detection/ftc-sample-detection-vyi5g

Provided by a Roboflow user
License: CC BY 4.0

